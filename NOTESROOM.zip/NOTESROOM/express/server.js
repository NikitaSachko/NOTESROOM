const express = require('express');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require("path");
const fs = require('fs');
const multer = require('multer');

const app = express();


app.use(express.json()); // для JSON в теле
app.use(express.urlencoded({ extended: true })); // для form-urlencoded

app.get('/api/editpas',(req,res)=>{
  res.status(200);
})

// Папка для загрузок
const uploadDir = path.join(__dirname, 'public', 'uploads');

// Создаём папку, если её нет
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}



// Настройка хранилища Multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Можно добавить уникальный префикс, чтобы избежать перезаписи
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // ограничение 5 МБ
  fileFilter: (req, file, cb) => {
    // Разрешаем только картинки
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Только изображения разрешены'));
    }
    cb(null, true);
  }
});



////



app.post('/api/edit/username', async (req, res) => {
  const { username } = req.body;
  await User.findByIdAndUpdate(req.session.userId, { username });
  res.json({ message: 'Username updated' });
});

// Обновление email
app.post('/api/user/update-email', async (req, res) => {
  const { email } = req.body;
  await User.findByIdAndUpdate(req.session.userId, { email });
  res.json({ message: 'Email updated' });
});

// Обновление password
app.post('/api/user/update-username', async (req, res) => {
  const { username, password } = req.body;
  // В вашем React-коде вы отправляете password на этот роут, поэтому принимаем его здесь
  if (password) {
    await User.findByIdAndUpdate(req.session.userId, { password });
    return res.json({ message: 'Password updated' });
  }
  if (username) {
    await User.findByIdAndUpdate(req.session.userId, { username });
    return res.json({ message: 'Username updated' });
  }
  res.status(400).json({ message: 'Нет данных для обновления' });
});

// Загрузка аватара
app.post('/api/user/update-avatar', upload.single('avatar'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'Файл не загружен' });
  }
  const imgSrc = '/uploads/' + req.file.filename;
  await User.findByIdAndUpdate(req.session.userId, { imgSrc });
  res.json({ message: 'Avatar updated', imgSrc });
});


///



const usersImg = ['1.jpg','/logos/2.webp','/logos/3.webp'];

app.use(express.static(path.join(__dirname, 'public')));


app.get('/api/ping', (req, res) => {
  res.json({ message: 'pong' });
});
// app.get('/login', (req, res) => {
//   res.sendFile(path.join(__dirname, 'public/login.html'));
// });

// app.get('/register', (req, res) => {
//   res.sendFile(path.join(__dirname, 'public/register.html'));
// });

const store = new MongoDBStore({
  uri: 'mongodb://localhost:27017/notesroom_sessions',
  collection: 'sessions'
});

mongoose.connect('mongodb://localhost:27017/notesroom', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('Connected!')).catch(err => console.error('Connection error:', err));;

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,  // Обязательное поле
  },
  email: {
    type: String,
    required: true,  // Обязательное поле
    unique: true     // Уникальное значение
  },
  password: {
    type: String,
    required: true
  },
  imgSrc:{
    type: String,
    required: true,  // Обязательное поле
  },
  notes: [{
    title: String,
    content: String,
    createdAt: { type: Date, default: Date.now }
  }]
},{ timestamps: true });
const User = mongoose.model('User', UserSchema);

app.use(cors({
  origin: 'http://localhost:5173', 
  credentials: true
}));

app.use(express.json());
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  store: store,
  cookie: {
    maxAge: 86400000,
    httpOnly: true,
    secure: false
  }
}));

const checkAuth = async (req, res, next) => {
  if (req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      
      if (user) {
        return res.redirect('/app');
      }
    } catch (err) {
      console.error('Ошибка проверки пользователя:', err);
    }
  }
  next();
};





app.get('/login', checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public/login.html'));
});

app.get('/register', checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public/register.html'));
});

app.post('/api/register', async (req, res) => {
  console.log(req.body.email);
  console.log(req.body.password);
    console.log(req.body.nickname);


  try {
    const existingUser = await User.findOne({ email:req.body.email });
    console.log(existingUser);
    if(existingUser){
      console.log('Такой пользователь уже есть.Измени почту');
      return res.status(409).json({ error: 'Пользователь с таким email уже существует' });
    }
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const user = new User({
      username: req.body.nickname,
      email: req.body.email,
      password: hashedPassword,
      imgSrc: usersImg[Math.floor(Math.random() * usersImg.length)],
    });
    await user.save();
    req.session.userId = user._id;
    res.status(201).json({ message: 'User created' });
  } catch (error) {

    console.error('Ошибка регистрации:', error);
    
    if (error.code === 11000 && error.keyPattern.email) {
      return res.status(409).json({ error: 'Пользователь с таким email уже существует' });
    }
    
    res.status(500).json({ error: 'Ошибка сервера при регистрации' });


  }
});

app.post('/api/login', async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (user && await bcrypt.compare(req.body.password, user.password)) {
    req.session.userId = user._id;
    res.json({ message: 'Login successful' });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});


app.get('/api/session', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Пользователь не аутентифицирован' });
  }
  try {
    const user = await User.findById(req.session.userId).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }
    res.json({
      username: user.username,
      email: user.email,
      imgSrc: user.imgSrc,
      notes: user.notes,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});


app.post('/api/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ error: 'Ошибка при выходе' });
    }
    res.clearCookie('connect.sid'); 
    res.json({ success: true, message: 'Выход выполнен' });
  });
});

////////////////profile and user edites editing



const port = 3001;

app.listen(port, () => console.log('Server running on port '+port));