import React, { useState, useRef, useEffect } from 'react';

const translations = {
  en: {
    profile: 'Profile',
    logout: 'Log Out',
    home: 'Home',
  },
  ru: {
    profile: 'Профиль',
    logout: 'Выйти из аккаунта',
    home: 'На главную',
  },
};

export default function UserWindow({theme, user, lang, logOutFunc, openProfileFunc }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuOpen]);

  const t = translations[lang] || translations.en;

  return (
    <div className='menu' style={{ borderRadius:'8px', padding:'10px 10px 10px 10px', backgroundColor:theme == 'b'? "#fbceb1" : 'white', position: 'relative', display: 'inline-block', fontFamily: 'Arial, sans-serif' }} ref={menuRef}>

      <div style={{ marginBottom: 8, fontWeight: 'bold', userSelect: 'none' }}>{user.username}</div>

      <button
        onClick={() => setMenuOpen(prev => !prev)}
        aria-haspopup="true"
        aria-expanded={menuOpen}
        style={{
          border: 'none',
          background: 'none',
          padding: 0,
          cursor: 'pointer',
          borderRadius: '50%',
          overflow: 'hidden',
          width: 48,
          height: 48,
          boxShadow: menuOpen ? '0 0 8px rgba(0,0,0,0.3)' : 'none',
          transition: 'box-shadow 0.3s ease',
        }}
        aria-label="User menu toggle"
        type="button"
      >
        <img
          src={`http://localhost:3001/${user.imgSrc.replace(/^\/+/, '')}`}
          alt={`${user.username} avatar`}
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
        />
      </button>

      <div
        style={{
          position: 'absolute',
          top: 'calc(100% + 8px)',
          right: 0,
          backgroundColor: 'white',
          borderRadius: 6,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
          overflow: 'hidden',
          width: 160,
          transformOrigin: 'top right',
          transition: 'transform 0.25s ease, opacity 0.25s ease',
          transform: menuOpen ? 'scaleY(1)' : 'scaleY(0)',
          opacity: menuOpen ? 1 : 0,
          pointerEvents: menuOpen ? 'auto' : 'none',
          zIndex: 1000,
        }}
        role="menu"
        aria-hidden={!menuOpen}
      >
        <button
          onClick={() => {
            openProfileFunc();
            setMenuOpen(false);
          }}
          role="menuitem"
          style={menuButtonStyle}
          type="button"
        >
          {t.profile}
        </button>
        <button
          onClick={() => {
            logOutFunc();
            setMenuOpen(false);
          }}
          role="menuitem"
          style={menuButtonStyle}
          type="button"
        >
          {t.logout}
        </button>
        <a
          href="/"
          role="menuitem"
          onClick={() => setMenuOpen(false)}
          style={{ ...menuButtonStyle, textDecoration: 'none', color: 'inherit', display: 'block', textAlign: 'left' }}
        >
          {t.home}
        </a>
      </div>
    </div>
  );
}

const menuButtonStyle = {
  width: '100%',
  padding: '10px 16px',
  background: 'none',
  border: 'none',
  textAlign: 'left',
  cursor: 'pointer',
  fontSize: 14,
  color: '#333',
  userSelect: 'none',
  outline: 'none',
  borderBottom: '1px solid #eee',
};

