import React, { useState, useRef } from 'react';

function UserProfile({ user, closeProfileFunc, language, themeColor }) {
  // Состояния для каждого поля отдельно (без логики запросов)
  const [username, setUsername] = useState(user.username);
  const [email, setEmail] = useState(user.email);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  // Обработчики изменения полей (без запросов)
  const handleUsernameChange = e => setUsername(e.target.value);
  const handleEmailChange = e => setEmail(e.target.value);
  const handlePasswordChange = e => setPassword(e.target.value);

  // Заглушки для кнопок (без логики)
  const saveUsername = () => {};
  const saveEmail = () => {};
  const savePassword = () => {};
  const handleFileChange = () => {};

  return (
    <div style={{ backgroundColor: themeColor === 'w' ? 'whitesmoke' : '#fdd9b5', maxWidth: 400, padding: 20, margin: 'auto', fontFamily: 'Arial, sans-serif' }}>
      {/* Стрелка назад */}
      <div
        onClick={closeProfileFunc}
        style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', marginBottom: 20, userSelect: 'none' }}
        title={language === 'ru' ? "Вернуться назад" : "Back"}
      >
        <span style={{ fontSize: 24, marginRight: 8 }}>←</span>
        <span style={{ paddingTop: 10, fontSize: 16, color: '#007bff' }}>
          {language === 'ru' ? "Вернуться назад" : "Back"}
        </span>
      </div>

      {/* Аватар (без логики загрузки) */}
      <div
        style={{ transition: '0.2s', position: 'relative', width: 150, height: 150, margin: 'auto', cursor: 'pointer' }}
        onClick={() => fileInputRef.current && fileInputRef.current.click()}
      >
        <img
          src={`http://localhost:3001${user.imgSrc}`}
          alt="Аватар"
          style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover', transition: '0.3s' }}
        />
        <div
          style={{
            position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)', color: 'white',
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            borderRadius: '50%', fontWeight: 'bold', fontSize: 16, userSelect: 'none',
          }}
        >
          {language === 'ru' ? "Изменить фото" : "Change photo"}
        </div>
        <input
          type="file"
          accept="image/*"
          style={{ display: 'none' }}
          ref={fileInputRef}
          onChange={handleFileChange}
          disabled={loading}
        />
      </div>

      {/* Username */}
      <div style={{ marginTop: 30, marginBottom: 15 }}>
        <b>{language === 'ru' ? 'Никнейм:' : 'Username:'} </b>
        <input
          value={username}
          onChange={handleUsernameChange}
          disabled={loading}
          style={{ marginRight: 8 }}
        />
        <button onClick={saveUsername} disabled={loading}>
          {language === 'ru' ? "Изменить" : "Edit"}
        </button>
      </div>

      {/* Email */}
      <div style={{ marginBottom: 15 }}>
        <b>{language === 'ru' ? 'Почта:' : 'Email:'} </b>
        <input
          value={email}
          onChange={handleEmailChange}
          disabled={loading}
          style={{ marginRight: 8 }}
        />
        <button onClick={saveEmail} disabled={loading}>
          {language === 'ru' ? "Изменить" : "Edit"}
        </button>
      </div>

      {/* Password */}
      <div style={{ marginBottom: 15 }}>
        <b>{language === 'ru' ? 'Пароль:' : 'Password:'} </b>
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
          disabled={loading}
          style={{ marginRight: 8 }}
          placeholder={language === 'ru' ? "Новый пароль" : "New password"}
        />
        <button onClick={savePassword} disabled={loading}>
          {language === 'ru' ? "Изменить" : "Edit"}
        </button>
      </div>

      {/* Ошибка */}
      {error && <div style={{ color: 'red', marginTop: 10 }}>{error}</div>}
    </div>
  );
}

export default UserProfile;
