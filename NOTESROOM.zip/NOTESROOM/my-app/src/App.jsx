
import { useState,useEffect } from 'react'
import './App.css'
import UserProfile from './components/UserProfile';
import UserWindow from './components/UserWindow';


function logout() {
  fetch('/api/logout', {
    method: 'POST',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      console.log('Выход успешен');
     // window.location = '/home';
    } else {
      console.error('Ошибка выхода');
    }
  })
  .catch(err => console.error('Ошибка запроса:', err));
}

function App() {

  const [profileClosed,setProfileClosed] = useState(localStorage.getItem('profileClosed') ? localStorage.getItem('profileClosed') === 'true' : true);



  function OpenProfile(){
    setProfileClosed(false);
    localStorage.setItem('profileClosed', 'false');

  }

  useEffect(()=>{
    console.log('profileClosed изменился он равен = ' + profileClosed);
  },[profileClosed])

  function CloseProfile(){
    setProfileClosed(true);
    localStorage.setItem('profileClosed', 'true');

  }


  /////api


  const [user, setUser] = useState();       // Данные пользователя
  const [loading, setLoading] = useState(true); // Состояние загрузки
  const [error, setError] = useState(null);     // Ошибка загрузки


  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await fetch('/api/session', { credentials: 'include' });
        if (!res.ok) throw new Error('Ошибка авторизации');
        const data = await res.json();
        setUser(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);


  useEffect(() => {
    console.log('user изменился:', user);
  }, [user]);
   

  //////


  
  const [theme,setTheme] = useState(localStorage.getItem('theme') ? localStorage.getItem('theme'):'b');
  const [lang,setLang] = useState(localStorage.getItem('lang') || 'ru');

  //////

  
  
function getDaysInMonth(month, year) {
  return new Date(year, month + 1, 0).getDate();
}

const monthNames = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
];

const monthNames2 = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

  //slider dates

 const now = new Date();
  const [currentMonth, setCurrentMonth] = useState(now.getMonth());
  const [selectedDay, setSelectedDay] = useState(null);
  const year = now.getFullYear();

  const daysInMonth = getDaysInMonth(currentMonth, year);



  ////



  ///func dates

const handlePrevMonth = () => {
    setCurrentMonth((prev) => (prev === 0 ? 11 : prev - 1));
    setSelectedDay(null);
  };
  const handleNextMonth = () => {
    setCurrentMonth((prev) => (prev === 11 ? 0 : prev + 1));
    setSelectedDay(null);
  };

  const handleDayClick = (day) => {
    setSelectedDay({ day, month: currentMonth, year });
  };

  ////func fates


  const ToogleTheme = ()=>{
    setTheme(prev => prev == 'w' ? 'b' : 'w');

  }

  useEffect(() => {
  localStorage.setItem('theme', theme);
}, [theme]);

  const ToogleLang = ()=>{
    setLang(prevLang => prevLang === 'en' ? 'ru' : 'en');
  }

  useEffect(() => {
  localStorage.setItem('lang', lang);
}, [lang]);




  //returns 



if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div className="loader"></div> {/* Здесь ваш кружок загрузки, можно стилизовать через CSS */}
      </div>
    );
  }

  if (error) {
    return <div style={{ color: 'red', textAlign: 'center', marginTop: 20 }}>Ошибка: {error}</div>;
  }

  if (!user) {
    return <div style={{ textAlign: 'center', marginTop: 20 }}>Пользователь не найден</div>;
  }


  return (
    
    <div id='mainDiv'>
    <div style={{backgroundColor: theme == 'b'? "#fdd9b5" : 'whitesmoke',}} className="header">
      <div className="container">
        <div className="header__inner">
          <div className="header__left">
            <h2>Notesroom</h2>

          </div>
          <div className="header__right">
                <button onClick={ToogleLang} style={{backgroundColor: theme == 'b'? "#fbceb1" : 'white',}}><img style={{marginRight:15}} className='icons' src="./translate.png" alt="lang" />{lang}</button>
                <button onClick={ToogleTheme} style={{backgroundColor: theme == 'b'? "#fbceb1" : 'white',}}><img className='icons' src="./theme.png" alt="theme" /></button>
         
                <UserWindow theme={theme} user={user} lang={lang} logOutFunc={logout} openProfileFunc={OpenProfile} />

          </div>
        </div>
      </div>
    </div>

<hr
  style={{
    
    width: '100%',
    border: 'none',
    borderTop: '5px solid black'
  }}
/>

  {profileClosed &&  <div style={{backgroundColor: theme == 'b'? "#fdd9b5" : 'whitesmoke'}}  className="content">
      <div className="container">
        <div className="content__inner">
            

 {/* Левая панель */}
      <div style={{
        width: 320,
        background: "#fff",
        borderRadius: "20px 0 0 20px",
        padding: 24,
        boxSizing: "border-box",
        boxShadow: "2px 0 12px #e6e6e6"
      }}>
        <h2 style={{ margin: "0 0 16px 0" }}>{lang == 'ru' ? 'Записи' : 'Notes'}</h2>
        <div style={{ display: "flex", alignItems: "center", marginBottom: 8 }}>
          <button onClick={handlePrevMonth} style={{ marginRight: 8 }}>{"<"}</button>
          <span style={{ fontWeight: 600 }}>
            {lang == 'ru' ? monthNames[currentMonth] : monthNames2[currentMonth]} {year}
          </span>
          <button onClick={handleNextMonth} style={{ marginLeft: 8 }}>{">"}</button>
        </div>
        {/* Календарь */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, textAlign: "center", marginBottom: 8 }}>
          {lang == 'ru' ? ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((d) => (
            <div key={d} style={{ fontWeight: 600, color: "#d49a6a" }}>{d}</div>
          )) : ["Mon", "Tue", "Wed", "Th", "Fr", "Sat", "Sun"].map((d) => (
            <div key={d} style={{ fontWeight: 600, color: "#d49a6a" }}>{d}</div>
          ))}
          {/* Пустые ячейки для смещения дней недели */}
          {[...Array((new Date(year, currentMonth, 1).getDay() + 6) % 7)].map((_, i) => (
            <div key={"empty" + i}></div>
          ))}
          {/* Дни месяца */}
          {[...Array(daysInMonth)].map((_, i) => {
            const day = i + 1;
            const isSelected =
              selectedDay &&
              selectedDay.day === day &&
              selectedDay.month === currentMonth &&
              selectedDay.year === year;
            return (
              <div
                key={day}
                onClick={() => handleDayClick(day)}
                style={{
                  cursor: "pointer",
                  padding: "6px 0",
                  borderRadius: "50%",
                  background: isSelected ? "#d49a6a" : "transparent",
                  color: isSelected ? "#fff" : "#333",
                  fontWeight: isSelected ? 700 : 400,
                  border: isSelected ? "2px solid #d49a6a" : "2px solid transparent"
                }}
              >
                {day}
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 16 }}>
          {selectedDay ? (
            <span style={{ fontWeight: 600 }}>
              {selectedDay.day} {monthNames[selectedDay.month].toLowerCase()}
            </span>
          ) : (
            <span style={{ color: "#aaa" }}>{lang == 'ru' ? 'Выберите дату' : 'Choose date'}</span>
          )}
        </div>
      </div>

      {/* Правая панель */}
      <div style={{
        flex: 1,
        background: "#a28fc5",
        borderRadius: "0 20px 20px 0",
        marginLeft: 24,
        padding: 40,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div style={{
          background: "#fff",
          borderRadius: 20,
          padding: 40,
          minWidth: 400,
          minHeight: 300,
          boxShadow: "0 0 20px #e6e6e6",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center"
        }}>
          {!selectedDay ? (
            <div style={{ color: "#888", fontSize: 20 }}>
              {lang == 'ru' ? 'Выберите дату для записи' : "Choose date for a print"}
            </div>
          ) : (
            <>
              <div style={{
                fontWeight: 600,
                fontSize: 18,
                marginBottom: 24
              }}>
                {selectedDay.day} {monthNames[selectedDay.month].toLowerCase()} {selectedDay.year}
              </div>
              {/* Здесь форма для записи или список записей */}
              <div style={{ color: "#888", marginBottom: 16 }}>
                Здесь пока ничего нет
              </div>
              <button style={{
                background: "#219178",
                color: "#fff",
                border: "none",
                borderRadius: 24,
                fontWeight: 700,
                fontSize: 18,
                padding: "12px 32px",
                cursor: "pointer"
              }}>
                Добавить новую запись
              </button>
            </>
          )}
        </div>
      </div>


        </div>
      </div>
    </div>
}

{profileClosed == false && 

 <UserProfile user={user} closeProfileFunc = {CloseProfile} language = {lang} themeColor = {theme} />


}



    </div>

  )
}

export default App
